# ClipGenius AI

A working starter application for uploading a video, generating candidate highlight moments, and exporting trimmed/cropped MP4 clips.

## Requirements
- Python 3.10+
- FFmpeg and FFprobe installed and available on PATH
- Recommended: 4 GB+ RAM for local Whisper transcription

## Run locally
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
uvicorn app:app --reload
```
Open http://127.0.0.1:8000

If `faster-whisper` cannot load a model, the app falls back to basic time-based suggestions. The first Whisper run downloads the selected model. Set `WHISPER_MODEL=tiny` for a smaller/faster model or `base` for better transcription.

## Run with Docker
```bash
docker build -t clipgenius-ai .
docker run --rm -p 8000:8000 -v "$(pwd)/uploads:/app/uploads" -v "$(pwd)/outputs:/app/outputs" clipgenius-ai
```

## What works
- Video upload and validation
- Video duration detection
- Optional Whisper transcription
- Transcript-window highlight suggestions with heuristic scores
- Real MP4 rendering with FFmpeg
- 9:16, 1:1 and 16:9 center-cropped exports
- 720p, 1080p and 4K output selection (hardware/source limits apply)

## Current limitations
- YouTube URL downloading is intentionally not implemented. Use a video file you own or have permission to edit, or integrate an authorized source provider/API.
- Scores are heuristic, not a guarantee of virality.
- Caption dropdown is a visual preset selector; burned-in word-synced captions are not implemented yet.
- Face tracking, advanced silence removal, background music, login, billing, and persistent project database are future modules.
- This is a local MVP, not yet production-hardened. Add authentication, upload-size limits, per-user storage isolation, job queue, cleanup policies, rate limits, and HTTPS before public deployment.
- Do not use it to download or republish videos without the rights or permission to do so.
