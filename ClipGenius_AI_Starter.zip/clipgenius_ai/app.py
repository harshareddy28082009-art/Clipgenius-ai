import os, uuid, subprocess, json, shutil
from pathlib import Path
from typing import Optional
from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.responses import HTMLResponse, FileResponse
from fastapi.staticfiles import StaticFiles

BASE = Path(__file__).parent
UPLOADS = BASE / "uploads"
OUTPUTS = BASE / "outputs"
UPLOADS.mkdir(exist_ok=True)
OUTPUTS.mkdir(exist_ok=True)

app = FastAPI(title="ClipGenius AI")
app.mount("/static", StaticFiles(directory=BASE / "static"), name="static")
app.mount("/outputs", StaticFiles(directory=OUTPUTS), name="outputs")

def run(cmd):
    p = subprocess.run(cmd, capture_output=True, text=True)
    if p.returncode != 0:
        raise RuntimeError(p.stderr[-1800:] or "Processing failed")
    return p.stdout

def duration_seconds(path: Path) -> float:
    out = run(["ffprobe", "-v", "error", "-show_entries", "format=duration",
               "-of", "default=noprint_wrappers=1:nokey=1", str(path)])
    return float(out.strip())

def transcribe(path: Path):
    # Optional dependency: faster-whisper. If unavailable, the app still creates
    # usable time-based clip suggestions and clearly labels them as such.
    try:
        from faster_whisper import WhisperModel
        model = WhisperModel(os.getenv("WHISPER_MODEL", "base"), device="cpu", compute_type="int8")
        segments, _ = model.transcribe(str(path), vad_filter=True)
        return [{"start": float(s.start), "end": float(s.end), "text": s.text.strip()}
                for s in segments if s.text.strip()], True
    except Exception:
        return [], False

def suggest_clips(duration: float, segments, clip_len: int):
    if segments:
        # Rank short transcript windows using simple hook/engagement phrase signals.
        keywords = ["but", "secret", "never", "why", "how", "amazing", "crazy",
                    "important", "mistake", "surprise", "best", "worst", "imagine",
                    "truth", "actually", "shocking", "because", "wow"]
        candidates = []
        step = max(8, clip_len // 2)
        for start in range(0, max(1, int(duration - clip_len + 1)), step):
            end = min(duration, start + clip_len)
            text = " ".join(s["text"] for s in segments if s["start"] < end and s["end"] > start)
            if not text.strip():
                continue
            low = text.lower()
            score = 45 + min(30, sum(low.count(k) for k in keywords) * 5)
            score += min(15, len(text.split()) // 12)
            candidates.append((min(98, score), start, end, text))
        candidates.sort(reverse=True)
        chosen, used = [], []
        for score, start, end, text in candidates:
            if all(abs(start - x) > clip_len * .65 for x in used):
                chosen.append({"score": score, "start": start, "end": end,
                               "title": " ".join(text.split()[:8]).strip(".,!?") or "Highlight moment",
                               "transcript": text})
                used.append(start)
            if len(chosen) == 5:
                break
        if chosen:
            return chosen
    # Fallback suggestions when transcription isn't installed or audio has no speech.
    count = min(5, max(1, int(duration // max(clip_len, 1))))
    return [{"score": 60, "start": round(i * duration / count, 2),
             "end": round(min(duration, i * duration / count + clip_len), 2),
             "title": f"Highlight {i+1}", "transcript": "Transcript unavailable — install faster-whisper for AI transcription."}
            for i in range(count)]

@app.get("/", response_class=HTMLResponse)
def home():
    return (BASE / "static" / "index.html").read_text(encoding="utf-8")

@app.post("/api/analyze")
async def analyze(video: UploadFile = File(...), clip_duration: int = Form(30)):
    if clip_duration not in (15, 30, 45, 60):
        raise HTTPException(400, "Choose 15, 30, 45 or 60 seconds.")
    suffix = Path(video.filename or "video.mp4").suffix.lower()
    if suffix not in (".mp4", ".mov", ".mkv", ".webm", ".avi", ".m4v"):
        raise HTTPException(400, "Upload an MP4, MOV, MKV, WEBM, AVI or M4V video.")
    job = uuid.uuid4().hex
    source = UPLOADS / f"{job}{suffix}"
    with source.open("wb") as f:
        shutil.copyfileobj(video.file, f)
    try:
        dur = duration_seconds(source)
        if dur <= 0:
            raise RuntimeError("Could not read video duration.")
        segments, has_transcript = transcribe(source)
        clips = suggest_clips(dur, segments, clip_duration)
        return {"job_id": job, "duration": dur, "transcription_available": has_transcript,
                "clips": clips, "message": "Transcript-based suggestions" if has_transcript else
                "Basic time-based suggestions. Install faster-whisper to enable transcript analysis."}
    except Exception as e:
        source.unlink(missing_ok=True)
        raise HTTPException(500, str(e))

@app.post("/api/render")
async def render(job_id: str = Form(...), start: float = Form(...), end: float = Form(...),
                 aspect: str = Form("9:16"), quality: str = Form("1080")):
    matches = list(UPLOADS.glob(job_id + ".*"))
    if not matches:
        raise HTTPException(404, "Original upload not found. Please upload again.")
    src = matches[0]
    if start < 0 or end <= start or end - start > 120:
        raise HTTPException(400, "Invalid clip time range (maximum 120 seconds).")
    if aspect not in ("9:16", "1:1", "16:9"):
        raise HTTPException(400, "Invalid aspect ratio.")
    height = {"720": 720, "1080": 1080, "2160": 2160}.get(quality, 1080)
    width = {"9:16": int(height * 9 / 16), "1:1": height, "16:9": int(height * 16 / 9)}[aspect]
    out = OUTPUTS / f"{job_id}_{int(start*1000)}_{uuid.uuid4().hex[:6]}.mp4"
    # Scale-to-fill + center crop, H.264/AAC output.
    vf = f"scale={width}:{height}:force_original_aspect_ratio=increase,crop={width}:{height},setsar=1"
    try:
        run(["ffmpeg", "-y", "-ss", str(start), "-i", str(src), "-t", str(end-start),
             "-vf", vf, "-c:v", "libx264", "-preset", "veryfast", "-crf", "21",
             "-c:a", "aac", "-b:a", "160k", "-movflags", "+faststart", str(out)])
    except Exception as e:
        raise HTTPException(500, str(e))
    return {"url": f"/outputs/{out.name}", "filename": out.name}

@app.get("/api/health")
def health():
    return {"status": "ok", "ffmpeg": shutil.which("ffmpeg") is not None}
